---
layout: post
title: "Cara Membuat Blog Jekyll SEO Friendly"
date: 2025-09-18
categories: [jekyll]
tags: [jekyll, seo, tutorial]
---
Ini adalah artikel contoh untuk Jekyll.

## Judul H2
Konten artikel...

### Judul H3
Subkonten...
