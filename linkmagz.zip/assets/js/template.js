// Placeholder JS extracted from template
document.addEventListener("DOMContentLoaded", function() {
  console.log("Blue Theme Jekyll ready.");
});
