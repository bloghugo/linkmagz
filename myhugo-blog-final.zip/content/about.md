---
title: "Tentang Saya"
---

# Tentang Saya

Halo 👋, saya adalah admin blog ini.  
Saya menulis seputar **Hugo, SEO, dan Tutorial Web**.  

Kontak: [Email](mailto:admin@example.com)
